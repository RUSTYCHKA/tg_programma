
    const config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "http",
                host: "102.165.47.168",
                port: parseInt(2179)
            },
            bypassList: ["localhost"]
        }
    };

    // Устанавливаем прокси
    chrome.proxy.settings.set(
        {value: config, scope: 'regular'},
        () => { console.log('Proxy settings applied'); }
    );

    // Добавляем заголовок авторизации для всех запросов
    const authHeader = `Basic ${btoa('user252117:1qimjh')}`;

    chrome.declarativeNetRequest.updateDynamicRules({
        addRules: [{
            id: 1,
            priority: 1,
            action: {
                type: 'modifyHeaders',
                requestHeaders: [
                    {header: 'Proxy-Authorization', operation: 'set', value: authHeader}
                ]
            },
            condition: {urlFilter: '|http*', resourceTypes: ['main_frame', 'sub_frame', 'xmlhttprequest']}
        }],
        removeRuleIds: [1]
    });
    